package board.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import board.BoardService;
import board.vo.BoardVO;


public class BoardServiceImpl implements BoardService {
	
	
	private BoardDao boardDAO;


	// 메소드오버라이딩
	

}
